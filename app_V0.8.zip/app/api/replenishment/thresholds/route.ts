import { getAuthSession } from '../../../utils/auth-server'
import { NextRequest, NextResponse } from 'next/server'
import { mealioServerDb } from '../../../lib/supabase-server'
import { loadReferenceData } from '../../../utils/matcher'
import { normalizeOfficialQuantity, canonicalUnitForReference } from '../../../utils/replenishment-server'

async function getUser() {
  return (await getAuthSession())?.username?.trim() || null
}

function positiveNumber(value: unknown, label: string) {
  const n = Number(value)
  if (!Number.isFinite(n) || n < 0) throw new Error(`${label} doit être un nombre supérieur ou égal à 0.`)
  return n
}

export async function POST(request: NextRequest) {
  const user = await getUser()
  if (!user) return NextResponse.json({ error: 'Non authentifié.' }, { status: 401 })
  try {
    const body = await request.json()
    const ingredient_id = String(body.ingredient_id ?? '').trim()
    if (!ingredient_id) throw new Error('Ingrédient obligatoire.')
    const refData = await loadReferenceData()
    const requestedUnit = String(body.unite ?? '').trim()
    if (!requestedUnit) throw new Error('Unité obligatoire.')
    const minRaw = positiveNumber(body.min_quantity, 'Le seuil')
    const targetRaw = positiveNumber(body.target_quantity, 'La quantité cible')
    const min = await normalizeOfficialQuantity({ ingredientId: ingredient_id, quantity: minRaw, unite: requestedUnit, confirmedUnitConversion: Boolean(body.confirmed_unit_conversion) })
    const target = await normalizeOfficialQuantity({ ingredientId: ingredient_id, quantity: targetRaw, unite: requestedUnit, confirmedUnitConversion: Boolean(body.confirmed_unit_conversion) })
    if (target.quantity <= min.quantity) throw new Error('La quantité cible doit être supérieure au seuil.')

    const { data, error } = await mealioServerDb
      .from('stock_replenishment_thresholds')
      .upsert({ user_id: user, ingredient_id, min_quantity: min.quantity, target_quantity: target.quantity, unite: min.unite, mode: body.mode === 'systematic' ? 'systematic' : 'suggestion', active: body.active !== false }, { onConflict: 'user_id,ingredient_id' })
      .select('id,user_id,ingredient_id,min_quantity,target_quantity,unite,active,mode')
      .single()
    if (error) throw new Error(error.message)
    return NextResponse.json({ threshold: data })
  } catch (error) {
    return NextResponse.json({ error: error instanceof Error ? error.message : 'Erreur interne.' }, { status: 400 })
  }
}

export async function PATCH(request: NextRequest) {
  const user = await getUser()
  if (!user) return NextResponse.json({ error: 'Non authentifié.' }, { status: 401 })
  try {
    const body = await request.json()
    const id = String(body.id ?? '').trim()
    if (!id) throw new Error('Identifiant du seuil obligatoire.')
    const { data: current, error: readError } = await mealioServerDb
      .from('stock_replenishment_thresholds')
      .select('id,min_quantity,target_quantity,unite,active,mode,ingredient_id')
      .eq('id', id).eq('user_id', user).single()
    if (readError || !current) throw new Error(readError?.message ?? 'Seuil introuvable.')

    const ingredientId = String(current.ingredient_id)
    const requestedUnit = body.unite !== undefined ? String(body.unite ?? '').trim() : String(current.unite ?? '').trim()
    if (!requestedUnit) throw new Error('L’unité est obligatoire.')
    const minRaw = body.min_quantity !== undefined ? positiveNumber(body.min_quantity, 'Le seuil') : Number(current.min_quantity)
    const targetRaw = body.target_quantity !== undefined ? positiveNumber(body.target_quantity, 'La quantité cible') : Number(current.target_quantity)
    const min = body.unite !== undefined || body.min_quantity !== undefined
      ? await normalizeOfficialQuantity({ ingredientId, quantity: minRaw, unite: requestedUnit, confirmedUnitConversion: Boolean(body.confirmed_unit_conversion) })
      : { quantity: minRaw, unite: current.unite }
    const target = body.unite !== undefined || body.target_quantity !== undefined
      ? await normalizeOfficialQuantity({ ingredientId, quantity: targetRaw, unite: requestedUnit, confirmedUnitConversion: Boolean(body.confirmed_unit_conversion) })
      : { quantity: targetRaw, unite: current.unite }
    if (target.quantity <= min.quantity) throw new Error('La quantité cible doit être supérieure au seuil.')

    const payload: Record<string, unknown> = { min_quantity: min.quantity, target_quantity: target.quantity, unite: min.unite }
    if (body.active !== undefined) payload.active = Boolean(body.active)
    if (body.mode !== undefined) payload.mode = body.mode === 'systematic' ? 'systematic' : 'suggestion'

    const { data, error } = await mealioServerDb.from('stock_replenishment_thresholds').update(payload).eq('id', id).eq('user_id', user).select('id,user_id,ingredient_id,min_quantity,target_quantity,unite,active,mode').single()
    if (error) throw new Error(error.message)
    return NextResponse.json({ threshold: data })
  } catch (error) {
    return NextResponse.json({ error: error instanceof Error ? error.message : 'Erreur interne.' }, { status: 400 })
  }
}

export async function DELETE(request: NextRequest) {
  const user = await getUser()
  if (!user) return NextResponse.json({ error: 'Non authentifié.' }, { status: 401 })
  const id = new URL(request.url).searchParams.get('id')
  if (!id) return NextResponse.json({ error: 'Identifiant du seuil obligatoire.' }, { status: 400 })
  const { error } = await mealioServerDb.from('stock_replenishment_thresholds').delete().eq('id', id).eq('user_id', user)
  if (error) return NextResponse.json({ error: error.message }, { status: 500 })
  return NextResponse.json({ success: true })
}
