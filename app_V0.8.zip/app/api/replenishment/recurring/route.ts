import { getAuthSession } from '../../../utils/auth-server'
import { NextRequest, NextResponse } from 'next/server'
import { mealioServerDb } from '../../../lib/supabase-server'
import { normalizeOfficialQuantity } from '../../../utils/replenishment-server'

async function getUser() {
  return (await getAuthSession())?.username?.trim() || null
}

async function normalizeRecurringQuantity(ingredientId: string | null, quantity: number, unit: string, confirmed: boolean) {
  if (!ingredientId) return { quantity, unite: unit }
  return normalizeOfficialQuantity({ ingredientId, quantity, unite: unit, confirmedUnitConversion: confirmed })
}

export async function POST(request: NextRequest) {
  const user = await getUser()
  if (!user) return NextResponse.json({ error: 'Non authentifié.' }, { status: 401 })
  try {
    const body = await request.json()
    const produit = String(body.produit ?? '').trim()
    const ingredientId = body.ingredient_id ? String(body.ingredient_id) : null
    const uniteRaw = String(body.unite ?? '').trim()
    const quantity = Number(body.quantity)
    const interval_days = Number(body.interval_days)
    const next_due_date = String(body.next_due_date ?? '').trim()
    const mode = body.mode === 'systematic' ? 'systematic' : 'suggestion'
    if (!produit || !uniteRaw || !next_due_date) throw new Error('Produit, unité et prochaine échéance sont obligatoires.')
    if (!Number.isFinite(quantity) || quantity <= 0) throw new Error('La quantité doit être supérieure à 0.')
    if (!Number.isInteger(interval_days) || interval_days <= 0) throw new Error('La fréquence doit être un nombre entier de jours supérieur à 0.')
    const normalized = await normalizeRecurringQuantity(ingredientId, quantity, uniteRaw, Boolean(body.confirmed_unit_conversion))

    const { data, error } = await mealioServerDb.from('recurring_purchase_rules').insert({
      user_id: user, ingredient_id: ingredientId, produit, quantity: normalized.quantity, unite: normalized.unite,
      rayon: body.rayon ? String(body.rayon) : null, interval_days, next_due_date, mode, active: body.active !== false,
    }).select('id,user_id,ingredient_id,produit,quantity,unite,rayon,interval_days,next_due_date,mode,active').single()
    if (error) throw new Error(error.message)
    return NextResponse.json({ recurring: data }, { status: 201 })
  } catch (error) {
    return NextResponse.json({ error: error instanceof Error ? error.message : 'Erreur interne.' }, { status: 400 })
  }
}

export async function PATCH(request: NextRequest) {
  const user = await getUser()
  if (!user) return NextResponse.json({ error: 'Non authentifié.' }, { status: 401 })
  try {
    const body = await request.json()
    const id = String(body.id ?? '').trim()
    if (!id) throw new Error('Identifiant du récurrent obligatoire.')
    const { data: current, error: readError } = await mealioServerDb.from('recurring_purchase_rules')
      .select('id,ingredient_id,produit,quantity,unite,rayon,interval_days,next_due_date,mode,active').eq('id', id).eq('user_id', user).single()
    if (readError || !current) throw new Error(readError?.message ?? 'Règle récurrente introuvable.')
    const produit = body.produit !== undefined ? String(body.produit ?? '').trim() : String(current.produit ?? '').trim()
    const ingredientId = body.ingredient_id !== undefined ? (body.ingredient_id ? String(body.ingredient_id) : null) : (current.ingredient_id ?? null)
    const unitChanged = body.unite !== undefined
    const quantityChanged = body.quantity !== undefined
    const unitRaw = unitChanged ? String(body.unite ?? '').trim() : String(current.unite ?? '').trim()
    const quantityRaw = quantityChanged ? Number(body.quantity) : Number(current.quantity)
    const intervalDays = body.interval_days !== undefined ? Number(body.interval_days) : Number(current.interval_days)
    const nextDue = body.next_due_date !== undefined ? String(body.next_due_date ?? '').trim() : String(current.next_due_date ?? '').trim()
    if (!produit || !unitRaw || !nextDue) throw new Error('Produit, unité et prochaine échéance sont obligatoires.')
    if (!Number.isFinite(quantityRaw) || quantityRaw <= 0) throw new Error('La quantité doit être supérieure à 0.')
    if (!Number.isInteger(intervalDays) || intervalDays <= 0) throw new Error('La fréquence doit être un nombre entier de jours supérieur à 0.')
    const normalized = unitChanged || quantityChanged || ingredientId !== current.ingredient_id
      ? await normalizeRecurringQuantity(ingredientId, quantityRaw, unitRaw, Boolean(body.confirmed_unit_conversion))
      : { quantity: quantityRaw, unite: current.unite }

    const payload: Record<string, unknown> = { produit, ingredient_id: ingredientId, quantity: normalized.quantity, unite: normalized.unite, interval_days: intervalDays, next_due_date: nextDue }
    if (body.rayon !== undefined) payload.rayon = body.rayon === null ? null : String(body.rayon)
    if (body.mode !== undefined) payload.mode = body.mode === 'systematic' ? 'systematic' : 'suggestion'
    if (body.active !== undefined) payload.active = Boolean(body.active)
    const { data, error } = await mealioServerDb.from('recurring_purchase_rules').update(payload).eq('id', id).eq('user_id', user).select('id,user_id,ingredient_id,produit,quantity,unite,rayon,interval_days,next_due_date,mode,active').single()
    if (error) throw new Error(error.message)
    return NextResponse.json({ recurring: data })
  } catch (error) {
    return NextResponse.json({ error: error instanceof Error ? error.message : 'Erreur interne.' }, { status: 400 })
  }
}

export async function DELETE(request: NextRequest) {
  const user = await getUser()
  if (!user) return NextResponse.json({ error: 'Non authentifié.' }, { status: 401 })
  const id = new URL(request.url).searchParams.get('id')
  if (!id) return NextResponse.json({ error: 'Identifiant du récurrent obligatoire.' }, { status: 400 })
  const { error } = await mealioServerDb.from('recurring_purchase_rules').delete().eq('id', id).eq('user_id', user)
  if (error) return NextResponse.json({ error: error.message }, { status: 500 })
  return NextResponse.json({ success: true })
}

export async function PUT(request: NextRequest) {
  const user = await getUser()
  if (!user) return NextResponse.json({ error: 'Non authentifié.' }, { status: 401 })
  try {
    const body = await request.json()
    const { markRecurringAdded } = await import('../../../utils/replenishment-server')
    await markRecurringAdded(String(body.id ?? ''), user)
    return NextResponse.json({ success: true })
  } catch (error) {
    return NextResponse.json({ error: error instanceof Error ? error.message : 'Erreur interne.' }, { status: 400 })
  }
}
