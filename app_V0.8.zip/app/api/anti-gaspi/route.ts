import { getAuthSession } from '../../utils/auth-server'
import { NextResponse } from 'next/server'
import {
  getAntiGaspiTonight,
  searchIngredientsForTonight,
  searchRecipesForSelectedLabels,
  searchRecipesForSelectedIngredientsAndStock,
} from '../../utils/anti-gaspi-server'

export async function GET(request: Request) {
  const username = (await getAuthSession())?.username?.trim()
  if (!username) return NextResponse.json({ error: 'Non authentifié.' }, { status: 401 })

  try {
    const url = new URL(request.url)
    const query = url.searchParams.get('q')?.trim() ?? ''
    if (query) {
      // La sélection utilisateur doit toujours reposer sur un ingrédient
      // officiel. On ne propose donc pas de pseudo-ID de type "label:..."
      // issu d'un libellé Cookiwiki non résolu.
      const ingredients = await searchIngredientsForTonight(username, query)
      return NextResponse.json({ ingredients })
    }
    return NextResponse.json(await getAntiGaspiTonight(username))
  } catch (error) {
    return NextResponse.json({ error: error instanceof Error ? error.message : 'Erreur interne.' }, { status: 500 })
  }
}

export async function POST(request: Request) {
  const username = (await getAuthSession())?.username?.trim()
  if (!username) return NextResponse.json({ error: 'Non authentifié.' }, { status: 401 })

  try {
    const body = await request.json().catch(() => ({}))
    const selectedIngredientIds = Array.isArray(body?.selectedIngredientIds) ? body.selectedIngredientIds.map(String) : []
    const selectedLabels = Array.isArray(body?.selectedLabels) ? body.selectedLabels.map(String) : []
    // Les IDs officiels sont la source de vérité. Les sélections stock sont
    // résolues vers le même référentiel afin que plusieurs sources puissent
    // être combinées avec une logique ET.
    const selectedKeys = Array.isArray(body?.selectedKeys) ? body.selectedKeys.map(String) : []
    if (selectedIngredientIds.length || selectedKeys.length) {
      return NextResponse.json(
        await searchRecipesForSelectedIngredientsAndStock(username, selectedIngredientIds, selectedKeys),
      )
    }
    if (selectedLabels.length) {
      return NextResponse.json(await searchRecipesForSelectedLabels(selectedLabels))
    }
    return NextResponse.json({ recipes: [], selectedStock: [] })
  } catch (error) {
    return NextResponse.json({ error: error instanceof Error ? error.message : 'Erreur interne.' }, { status: 500 })
  }
}
