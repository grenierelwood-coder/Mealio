import type { Metadata } from "next";
import { Geist, Geist_Mono } from "next/font/google";
import "./globals.css";
import ContextualHelp from './components/ContextualHelp';
import MealConsumptionPrompt from './components/MealConsumptionPrompt';
import MealioNav from './components/MealioNav';

const geistSans = Geist({ variable: "--font-geist-sans", subsets: ["latin"] });
const geistMono = Geist_Mono({ variable: "--font-geist-mono", subsets: ["latin"] });

export const metadata: Metadata = {
  title: "Mealio",
  description: "Planning, stocks et listes de courses intelligentes",
  manifest: "/site.webmanifest",
  icons: {
    icon: "/favicon.ico",
    apple: "/apple-touch-icon.png",
  },
};

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return (
    <html lang="fr" className={`${geistSans.variable} ${geistMono.variable} h-full antialiased`}>
      <body className="min-h-full flex flex-col"><MealioNav /><ContextualHelp /><MealConsumptionPrompt />{children}</body>
    </html>
  );
}
