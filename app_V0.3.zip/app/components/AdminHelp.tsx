'use client'

import { useState } from 'react'

export default function AdminHelp({
  title,
  intro,
  sections,
  warning,
}: {
  title: string
  intro: string
  sections: { title: string; children: React.ReactNode }[]
  warning?: string
}) {
  const [open, setOpen] = useState(false)

  return (
    <section className="rounded-2xl border border-slate-200 bg-white shadow-sm">
      <button
        type="button"
        onClick={() => setOpen(value => !value)}
        className="flex min-h-12 w-full items-center justify-between gap-3 px-4 py-3 text-left"
        aria-expanded={open}
      >
        <span className="font-black">ⓘ {title}</span>
        <span className="shrink-0 text-slate-400">{open ? '⌃' : '⌄'}</span>
      </button>

      {open && (
        <div className="border-t border-slate-100 px-4 pb-4 pt-3 text-sm text-slate-600">
          <p>{intro}</p>
          <div className="mt-3 space-y-3">
            {sections.map(section => (
              <div key={section.title}>
                <div className="font-black text-slate-800">{section.title}</div>
                <div className="mt-1">{section.children}</div>
              </div>
            ))}
          </div>
          {warning && (
            <div className="mt-4 rounded-xl border border-amber-200 bg-amber-50 p-3 text-xs font-semibold text-amber-900">
              ⚠️ {warning}
            </div>
          )}
        </div>
      )}
    </section>
  )
}
