import { NextResponse } from 'next/server'
import { createClient } from '@supabase/supabase-js'
import {
  AUTH_COOKIE_MAX_AGE,
  AUTH_COOKIE_NAME,
  createSessionValue,
} from '../../../utils/auth-server'

export const runtime = 'nodejs'

function requiredPublicEnv(name: string): string {
  const value = process.env[name]
  if (!value) throw new Error(`Variable d'environnement manquante : ${name}`)
  return value
}

/**
 * Authentification Mealio :
 * on conserve exactement la même source d'identité qu'avant (Frosti.app_users),
 * mais la requête est maintenant exécutée côté serveur.
 *
 * On utilise volontairement la clé ANON publique ici : c'est la même autorisation
 * que l'ancien login client qui fonctionnait déjà. Cela évite de rendre le login
 * dépendant de FROSTI_SERVICE_ROLE_KEY.
 */
export async function POST(request: Request) {
  let body: { username?: unknown; password?: unknown }

  try {
    body = await request.json()
  } catch {
    return NextResponse.json({ error: 'Corps JSON invalide.' }, { status: 400 })
  }

  const username = typeof body.username === 'string' ? body.username.trim() : ''
  const password = typeof body.password === 'string' ? body.password : ''

  if (!username || !password) {
    return NextResponse.json(
      { error: 'Identifiant et mot de passe requis.' },
      { status: 400 }
    )
  }

  try {
    const frostiDb = createClient(
      requiredPublicEnv('NEXT_PUBLIC_FROSTI_URL'),
      requiredPublicEnv('NEXT_PUBLIC_FROSTI_ANON_KEY'),
      {
        auth: {
          autoRefreshToken: false,
          persistSession: false,
          detectSessionInUrl: false,
        },
      }
    )

    const { data, error } = await frostiDb
      .from('app_users')
      .select('id, username')
      .eq('username', username)
      .eq('password', password)
      .single()

    if (error) {
      console.error('❌ Erreur authentification Frosti :', error.message)
      return NextResponse.json(
        { error: 'Identifiant ou mot de passe incorrect.' },
        { status: 401 }
      )
    }

    if (!data?.id || !data?.username) {
      return NextResponse.json(
        { error: 'Identifiant ou mot de passe incorrect.' },
        { status: 401 }
      )
    }

    const response = NextResponse.json({
      ok: true,
      username: data.username,
    })

    response.cookies.set({
      name: AUTH_COOKIE_NAME,
      value: createSessionValue(data.username, data.id),
      httpOnly: true,
      secure: process.env.NODE_ENV === 'production',
      sameSite: 'lax',
      path: '/',
      maxAge: AUTH_COOKIE_MAX_AGE,
    })

    return response
  } catch (error) {
    console.error('❌ Impossible d’initialiser l’authentification Frosti :', error)
    return NextResponse.json(
      { error: 'Service d’authentification indisponible.' },
      { status: 500 }
    )
  }
}
