'use client'

import { useEffect, useMemo, useState } from 'react'

interface PurchaseEvent {
  id: string
  list_id: string
  shopping_item_id: string
  produit: string
  ingredient_id: string | null
  quantity: number
  unite: string | null
  purchased_at: string
  status: 'a_ranger' | 'range' | 'historique'
  storage: 'frosti' | 'cellio' | null
  location_name: string | null
}

function formatNumber(value: number) {
  return Number.isInteger(value) ? String(value) : String(Number(value.toFixed(2)))
}

function formatDate(date: string) {
  return new Intl.DateTimeFormat('fr-FR', {
    weekday: 'long', day: 'numeric', month: 'long', year: 'numeric'
  }).format(new Date(date))
}

function formatTime(date: string) {
  return new Intl.DateTimeFormat('fr-FR', { hour: '2-digit', minute: '2-digit' }).format(new Date(date))
}

export default function PurchasesPage() {
  const [events, setEvents] = useState<PurchaseEvent[]>([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)

  useEffect(() => {
    fetch('/api/purchases', { cache: 'no-store' })
      .then(async response => {
        const result = await response.json()
        if (!response.ok) throw new Error(result?.error ?? 'Impossible de charger l’historique.')
        setEvents(result.purchases ?? [])
      })
      .catch(err => setError(err instanceof Error ? err.message : 'Impossible de charger l’historique.'))
      .finally(() => setLoading(false))
  }, [])

  const groups = useMemo(() => {
    const map = new Map<string, PurchaseEvent[]>()
    for (const event of events) {
      const key = new Date(event.purchased_at).toLocaleDateString('fr-FR')
      const list = map.get(key) ?? []
      list.push(event)
      map.set(key, list)
    }
    return Array.from(map.entries())
  }, [events])

  return (
    <main className="min-h-screen bg-stone-50 text-slate-900">
      <div className="mx-auto w-full max-w-4xl px-3 pb-16 pt-5 sm:px-5 sm:pt-7">
        <header className="mb-6">
          <div className="text-[10px] font-black uppercase tracking-[0.2em] text-emerald-600">Mealio</div>
          <h1 className="mt-1 text-3xl font-black tracking-tight">🧾 Historique des achats</h1>
          <p className="mt-1 text-sm text-slate-500">Ce que tu as déclaré comme acheté, classé par date. Le rangement est affiché séparément.</p>
        </header>

        {loading && <div className="rounded-2xl bg-white p-5 shadow-sm">Chargement…</div>}
        {error && <div className="rounded-2xl border border-red-200 bg-red-50 p-4 text-sm text-red-700">{error}</div>}
        {!loading && !error && events.length === 0 && <div className="rounded-2xl border border-slate-200 bg-white p-6 text-center text-sm text-slate-500">Aucun achat enregistré pour le moment.</div>}

        <div className="space-y-5">
          {groups.map(([day, dayEvents]) => (
            <section key={day} className="rounded-2xl border border-slate-200 bg-white p-4 shadow-sm sm:p-5">
              <h2 className="font-black capitalize text-slate-900">{formatDate(dayEvents[0].purchased_at)}</h2>
              <div className="mt-3 divide-y divide-slate-100">
                {dayEvents.map(event => (
                  <div key={event.id} className="flex flex-col gap-2 py-3 sm:flex-row sm:items-center sm:justify-between">
                    <div>
                      <div className="font-bold">{event.produit}</div>
                      <div className="text-xs text-slate-500">{formatTime(event.purchased_at)} · {event.status === 'range' ? '✓ rangé' : event.status === 'a_ranger' ? '⚠ acheté, rangement à faire' : 'historique'}</div>
                    </div>
                    <div className="text-sm font-black">
                      {formatNumber(Number(event.quantity))} {event.unite ?? ''}
                      {event.location_name && <span className="ml-2 font-semibold text-slate-500">→ {event.storage === 'frosti' ? '❄️ Frosti' : '🍷 Cellio'} · {event.location_name}</span>}
                    </div>
                  </div>
                ))}
              </div>
            </section>
          ))}
        </div>
      </div>
    </main>
  )
}
