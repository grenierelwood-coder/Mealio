import { mealioServerDb } from '../lib/supabase-server'
import { matchStockWithClaude, resolveOfficialIngredientWithClaude } from '../lib/anthropic-server'

export interface RecipeIngredient {
  name: string
  qty: number
  unit: string
}

export interface StockItem {
  id: string
  produit: string
  qte: number
  unite: string
  source?: string
}

type OfficialIngredient = {
  id: string
  nom: string
  rayon: string | null
  default_storage: string | null
}

type AiResolution = {
  mot_recette: string
  proposition_ia: string | null
  ingredient_id_propose: string | null
  statut: 'en_attente' | 'valide' | 'rejete'
  created_at: string | null
}

export interface ReferenceData {
  ignoredSet: Set<string>
  synonymMap: Map<string, string>
  officialList: OfficialIngredient[]
  officialById: Map<string, OfficialIngredient>
  officialPrepared: { item: OfficialIngredient; normalized: string; tokens: string[] }[]
  unitMappings: { unite: string; abreviation: string | null; type_unite: string | null; multiplicateur: number | null }[]
  densities: { ingredient_id: string; unite: string; poids_g_approx: number }[]
  aiResolutionMap: Map<string, AiResolution>
  aiCache: Map<string, string | null>
}

export interface MatcherTrace {
  ingredient: {
    raw: string
    normalized: string
    source:
      | 'ignored'
      | 'synonym'
      | 'exact'
      | 'lexical'
      | 'memory'
      | 'ai'
      | 'unresolved'
  }

  ingredientAiCalled: boolean
  ingredientAiCacheHit: boolean
  ingredientAiConfidence: number | null

  stock: {
    source:
      | 'memory'
      | 'exact'
      | 'lexical'
      | 'ai'
      | 'none'
      | null
    aiCalled: boolean
    memoryHit: boolean
    aiConfidence: number | null
  }

  claudeCalls: number
  events: string[]
}

export function createMatcherTrace(raw: string): MatcherTrace {
  return {
    ingredient: {
      raw,
      normalized: cleanText(raw),
      source: 'unresolved',
    },

    ingredientAiCalled: false,
    ingredientAiCacheHit: false,
    ingredientAiConfidence: null,

    stock: {
      source: null,
      aiCalled: false,
      memoryHit: false,
      aiConfidence: null,
    },

    claudeCalls: 0,
    events: [],
  }
}

const BASE_STOP_WORDS = new Set([
  'de', 'du', 'des', 'la', 'le', 'les', 'un', 'une', 'et', 'a', 'au', 'aux', 'en', 'pour', 'avec',
])

const CONFIG = {
  OFFICIAL_AUTO_SCORE: 0.93,
  OFFICIAL_AUTO_MARGIN: 0.08,
  STOCK_AUTO_SCORE: 0.93,
  STOCK_AUTO_MARGIN: 0.08,
  MIN_CANDIDATE_SCORE: 0.22,
  CANDIDATE_LIMIT: 5,
  AI_LEARNING_THRESHOLD: 0.85,
}

const DISCRIMINANT_GROUPS = [
  ['rouge', 'vert', 'jaune', 'orange'],
  ['cerise', 'grappe', 'concasse', 'conserve', 'seche'],
  ['coco', 'amande', 'noisette', 'noix', 'soja', 'avoine'],
  ['chevre', 'brebis', 'vache', 'bufflonne'],
  ['doux', 'sale', 'fume', 'epice', 'fort'],
  ['liquide', 'solide', 'poudre'],
]

const discriminantGroupByToken = new Map<string, number>()
DISCRIMINANT_GROUPS.forEach((group, index) => group.forEach(token => discriminantGroupByToken.set(token, index)))

function singularizeWord(word: string): string {
  if (!word || word.length <= 3) return word
  if (new Set(['riz', 'mais', 'pois', 'jus', 'os', 'frais']).has(word)) return word
  if (word.endsWith('ufs')) return word.slice(0, -1)
  if (word.endsWith('tes') || word.endsWith('ons') || word.endsWith('res') || word.endsWith('nes') || word.endsWith('mes') || word.endsWith('des') || word.endsWith('ves')) return word.slice(0, -1)
  if (word.endsWith('es')) return word.slice(0, -1)
  if (word.endsWith('s') && !word.endsWith('ss') && word.length >= 5) return word.slice(0, -1)
  return word
}

export function cleanText(text: string, stopWords?: Set<string>): string {
  if (!text) return ''
  const ignored = stopWords ?? BASE_STOP_WORDS
  return text
    .toLowerCase()
    .normalize('NFD').replace(/[\u0300-\u036f]/g, '')
    .replace(/[()[\],.;:/\\'"!?]/g, ' ')
    .replace(/\s+/g, ' ')
    .trim()
    .split(' ')
    .filter(Boolean)
    .map(singularizeWord)
    .filter(w => !ignored.has(w))
    .join(' ')
}

function tokens(text: string, stopWords: Set<string>): string[] {
  return cleanText(text, stopWords).split(' ').filter(Boolean)
}

function levenshtein(a: string, b: string): number {
  if (a === b) return 0
  if (!a.length) return b.length
  if (!b.length) return a.length
  const prev = Array.from({ length: b.length + 1 }, (_, i) => i)
  for (let i = 0; i < a.length; i++) {
    const curr = [i + 1]
    for (let j = 0; j < b.length; j++) {
      const cost = a[i] === b[j] ? 0 : 1
      curr.push(Math.min(curr[j] + 1, prev[j + 1] + 1, prev[j] + cost))
    }
    for (let j = 0; j < curr.length; j++) prev[j] = curr[j]
  }
  return prev[b.length]
}

function similarity(a: string, b: string): number {
  if (!a || !b) return 0
  if (a === b) return 1
  return Math.max(0, 1 - levenshtein(a, b) / Math.max(a.length, b.length))
}

function contradictionPenalty(aTokens: string[], bTokens: string[]): number {
  const groups = new Set<number>()
  for (const t of aTokens) {
    const g = discriminantGroupByToken.get(t)
    if (g !== undefined) groups.add(g)
  }
  for (const t of bTokens) {
    const g = discriminantGroupByToken.get(t)
    if (g !== undefined && groups.has(g) && !aTokens.includes(t)) return 0.18
  }
  return 0
}

function textScore(a: string, b: string, stopWords: Set<string>): number {
  const na = cleanText(a, stopWords)
  const nb = cleanText(b, stopWords)
  if (!na || !nb) return 0
  if (na === nb) return 1
  const at = tokens(na, stopWords)
  const bt = tokens(nb, stopWords)
  if (!at.length || !bt.length) return 0
  const bs = new Set(bt)
  const common = at.filter(t => bs.has(t)).length
  const coverageA = common / at.length
  const coverageB = common / bt.length
  let score = coverageA * 0.55 + coverageB * 0.20 + similarity(na, nb) * 0.25
  if (coverageA === 1) score += 0.04
  score -= contradictionPenalty(at, bt)
  return Math.min(0.97, Math.max(0, score))
}

function bestIsSafe<T extends { score: number }>(candidates: T[], minScore: number, minMargin: number): boolean {
  if (!candidates.length || candidates[0].score < minScore) return false
  const margin = candidates.length > 1 ? candidates[0].score - candidates[1].score : candidates[0].score
  return margin >= minMargin
}

export async function loadReferenceData(): Promise<ReferenceData> {
  const [ignored, synonyms, official, units, densities, aiLogs] = await Promise.all([
    mealioServerDb.from('ignored_words').select('mot'),
    mealioServerDb.from('ingredient_synonyms').select('mot_recette, ingredient_id'),
    mealioServerDb.from('official_ingredients').select('id, nom, rayon, default_storage'),
    mealioServerDb.from('unit_mappings').select('unite, abreviation, type_unite, multiplicateur'),
    mealioServerDb.from('ingredient_densities').select('ingredient_id, unite, poids_g_approx'),
    mealioServerDb.from('ai_resolution_log').select('mot_recette, proposition_ia, ingredient_id_propose, statut, created_at').order('created_at', { ascending: false }),
  ])

  if (ignored.error) console.error('ignored_words:', ignored.error.message)
  if (synonyms.error) console.error('ingredient_synonyms:', synonyms.error.message)
  if (official.error) console.error('official_ingredients:', official.error.message)
  if (units.error) console.error('unit_mappings:', units.error.message)
  if (densities.error) console.error('ingredient_densities:', densities.error.message)
  if (aiLogs.error) console.error('ai_resolution_log:', aiLogs.error.message)

  const officialList = (official.data ?? []) as OfficialIngredient[]
  const ignoredSet = new Set(BASE_STOP_WORDS)
  for (const row of ignored.data ?? []) {
    const value = cleanText(String(row.mot ?? ''), BASE_STOP_WORDS)
    if (value) ignoredSet.add(value)
  }

  const aiResolutionMap = new Map<string, AiResolution>()
  for (const row of aiLogs.data ?? []) {
    const key = cleanText(String(row.mot_recette ?? ''))
    if (key && !aiResolutionMap.has(key)) aiResolutionMap.set(key, row as AiResolution)
  }

  return {
    ignoredSet,
    synonymMap: new Map((synonyms.data ?? []).map(s => [cleanText(s.mot_recette), s.ingredient_id])),
    officialList,
    officialById: new Map(officialList.map(o => [o.id, o])),
    officialPrepared: officialList.map(item => ({ item, normalized: cleanText(item.nom, ignoredSet), tokens: tokens(item.nom, ignoredSet) })),
    unitMappings: units.data ?? [],
    densities: densities.data ?? [],
    aiResolutionMap,
    aiCache: new Map(),
  }
}

function findUnitMapping(refData: ReferenceData, unit: string) {
  const cleaned = cleanText(unit)
  return refData.unitMappings.find(u => cleanText(u.unite) === cleaned || cleanText(u.abreviation ?? '') === cleaned)
}

function findDensity(refData: ReferenceData, ingredientId: string, unit: string) {
  const cleaned = cleanText(unit)
  return refData.densities.find(d => d.ingredient_id === ingredientId && cleanText(d.unite) === cleaned)
}

async function saveAiResolution(rawName: string, proposition: string | null, ingredientId: string | null): Promise<void> {
  const { error } = await mealioServerDb.from('ai_resolution_log').insert({
    mot_recette: rawName,
    proposition_ia: proposition ?? 'AUCUN',
    ingredient_id_propose: ingredientId,
    statut: 'en_attente',
  })
  if (error) console.error('ai_resolution_log insert:', error.message)
}

async function resolveOfficialIngredient(
  rawName: string,
  refData: ReferenceData,
  trace?: MatcherTrace
): Promise<{ id: string | null; name: string | null; aiProposed: boolean }> {
  const key = cleanText(rawName)
  if (!key || refData.ignoredSet.has(key)) return { id: null, name: null, aiProposed: false }

  const synonymId = refData.synonymMap.get(key)
if (synonymId) {
  const official = refData.officialById.get(synonymId)

  if (official) {
    if (trace) {
      trace.ingredient.source = 'synonym'
      trace.events.push(`Synonyme trouvé : ${official.nom}`)
    }

    return {
      id: official.id,
      name: official.nom,
      aiProposed: false,
    }
  }
}

  const exact = refData.officialPrepared.find(o => o.normalized === cleanText(rawName, refData.ignoredSet))
if (exact) {
  if (trace) {
    trace.ingredient.source = 'exact'
    trace.events.push(`Correspondance exacte : ${exact.item.nom}`)
  }

  return {
    id: exact.item.id,
    name: exact.item.nom,
    aiProposed: false,
  }
}

  const candidates = refData.officialPrepared
    .map(o => ({ ...o, score: textScore(rawName, o.item.nom, refData.ignoredSet) }))
    .filter(o => o.score >= CONFIG.MIN_CANDIDATE_SCORE)
    .sort((a, b) => b.score - a.score)
    .slice(0, CONFIG.CANDIDATE_LIMIT)

if (bestIsSafe(candidates, CONFIG.OFFICIAL_AUTO_SCORE, CONFIG.OFFICIAL_AUTO_MARGIN)) {
  if (trace) {
    trace.ingredient.source = 'lexical'
    trace.events.push(
      `Match lexical automatique : ${candidates[0].item.nom} (${candidates[0].score.toFixed(2)})`
    )
  }

  return {
    id: candidates[0].item.id,
    name: candidates[0].item.nom,
    aiProposed: false,
  }
}

  // Une proposition IA déjà enregistrée (validée ou en attente) évite un nouvel appel.
if (previous && trace) {
  trace.ingredientAiCacheHit = true
  trace.ingredient.source = 'memory'
  trace.events.push(
    `Mémoire IA utilisée : ${previous.proposition_ia ?? 'AUCUN'} (${previous.statut})`
  )
}
  if (previous) {
    if (previous.statut === 'rejete') return { id: null, name: null, aiProposed: false }
    if (previous.ingredient_id_propose) {
      const official = refData.officialById.get(previous.ingredient_id_propose)
      if (official) return { id: official.id, name: official.nom, aiProposed: previous.statut !== 'valide' }
    }
    if (previous.proposition_ia === 'AUCUN') return { id: null, name: null, aiProposed: false }
  }

  if (!candidates.length) {
    await saveAiResolution(rawName, null, null)
    refData.aiResolutionMap.set(key, {
      mot_recette: rawName,
      proposition_ia: 'AUCUN',
      ingredient_id_propose: null,
      statut: 'en_attente',
      created_at: new Date().toISOString(),
    })
    return { id: null, name: null, aiProposed: false }
  }

  
if (trace) {
  trace.ingredientAiCalled = true
  trace.claudeCalls += 1
  trace.events.push('Claude appelé pour résoudre l’ingrédient')
}

const ai = await resolveOfficialIngredientWithClaude(
    rawName,
    candidates.map(c => ({ id: c.item.id, label: c.item.nom, lexicalScore: c.score }))
  )

if (trace) {
  trace.ingredientAiConfidence = ai.confidence ?? null
  trace.events.push(
    `Claude a proposé : ${ai.matched ?? 'aucune correspondance'}`
  )
}

  const selected = ai.matched ? refData.officialById.get(ai.matched) : null
  await saveAiResolution(rawName, selected?.nom ?? null, selected?.id ?? null)
  refData.aiResolutionMap.set(key, {
    mot_recette: rawName,
    proposition_ia: selected?.nom ?? 'AUCUN',
    ingredient_id_propose: selected?.id ?? null,
    statut: 'en_attente',
    created_at: new Date().toISOString(),
  })

  return selected
    ? { id: selected.id, name: selected.nom, aiProposed: true }
    : { id: null, name: null, aiProposed: false }
}

export interface ResolvedIngredient {
  produit: string
  ingredient_id: string | null
  qte: number
  unite: string
  needs_review: boolean
  source_recipe_id: string
  source_recipe_nom: string
}

export async function resolveRecipeIngredients(
  recipeIngredients: RecipeIngredient[],
  refData: ReferenceData,
  recipeId: string,
  recipeNom: string,
  servingsRatio = 1,
  trace?: MatcherTrace,
): Promise<ResolvedIngredient[]> {
  const resolved: ResolvedIngredient[] = []

  for (const ing of recipeIngredients) {
    const rawName = cleanText(ing.name)
    if (!rawName || refData.ignoredSet.has(rawName)) continue

const official = await resolveOfficialIngredient(
  ing.name,
  refData,
  trace
)    
const ingredientId = official.id
    const standardProduct = official.name ?? ing.name
    let requiredQty = Number(ing.qty) * servingsRatio
    let requiredUnit = cleanText(ing.unit)
    let unitResolved = false

    if (ingredientId) {
      const density = findDensity(refData, ingredientId, ing.unit)
      if (density) {
        requiredQty *= Number(density.poids_g_approx)
        requiredUnit = 'g'
        unitResolved = true
      }
    }

    if (!unitResolved) {
      const mapping = findUnitMapping(refData, ing.unit)
      if (mapping) {
        if (mapping.type_unite === 'unité') requiredUnit = 'pièce'
        else if (mapping.type_unite === 'volume') {
          requiredQty *= Number(mapping.multiplicateur ?? 1)
          requiredUnit = 'mL'
        } else if (mapping.type_unite === 'poids') {
          requiredQty *= Number(mapping.multiplicateur ?? 1)
          requiredUnit = 'g'
        }
        unitResolved = true
      }
    }

    resolved.push({
      produit: standardProduct,
      ingredient_id: ingredientId,
      qte: requiredQty,
      unite: requiredUnit,
      needs_review: official.aiProposed || !unitResolved || !ingredientId,
      source_recipe_id: recipeId,
      source_recipe_nom: recipeNom,
    })
  }

  return resolved
}

export interface AggregatedRequirement {
  produit: string
  ingredient_id: string | null
  qte: number
  unite: string
  needs_review: boolean
  contributions: { recipe_id: string; recipe_nom: string; qte_contribuee: number }[]
}

export function aggregateRequirements(resolvedLists: ResolvedIngredient[][]): AggregatedRequirement[] {
  const map = new Map<string, AggregatedRequirement>()
  for (const list of resolvedLists) {
    for (const item of list) {
      const key = `${item.ingredient_id ?? cleanText(item.produit)}::${cleanText(item.unite)}`
      const existing = map.get(key)
      const contribution = { recipe_id: item.source_recipe_id, recipe_nom: item.source_recipe_nom, qte_contribuee: item.qte }
      if (existing) {
        existing.qte += item.qte
        existing.needs_review ||= item.needs_review
        existing.contributions.push(contribution)
      } else {
        map.set(key, { produit: item.produit, ingredient_id: item.ingredient_id, qte: item.qte, unite: item.unite, needs_review: item.needs_review, contributions: [contribution] })
      }
    }
  }
  return Array.from(map.values())
}

export interface ComparedRequirement extends AggregatedRequirement {
  qte_a_acheter: number
  ai_status: 'green' | 'orange' | 'red'
}

interface PreparedStock {
  item: StockItem
  normalized: string
  tokens: string[]
}

interface MemoryRow {
  ingredient_key: string
  stock_item_id: string
  source: 'ai' | 'human' | 'text' | 'exact'
  confidence: number
  validated: boolean
  reason: string | null
}

async function loadStockMemory(keys: string[]) {
  const unique = [...new Set(keys.filter(Boolean))]
  if (!unique.length) return { memory: new Map<string, MemoryRow[]>(), exclusions: new Set<string>() }

  const [memoryResult, exclusionResult] = await Promise.all([
    mealioServerDb.from('matcher_memory').select('ingredient_key, stock_item_id, source, confidence, validated, reason').in('ingredient_key', unique),
    mealioServerDb.from('matcher_exclusions').select('ingredient_key, stock_item_id').in('ingredient_key', unique),
  ])

  if (memoryResult.error) console.error('matcher_memory:', memoryResult.error.message)
  if (exclusionResult.error) console.error('matcher_exclusions:', exclusionResult.error.message)

  const memory = new Map<string, MemoryRow[]>()
  for (const row of (memoryResult.data ?? []) as MemoryRow[]) {
    const list = memory.get(row.ingredient_key) ?? []
    list.push(row)
    memory.set(row.ingredient_key, list)
  }
  for (const list of memory.values()) list.sort((a, b) => Number(b.validated) - Number(a.validated) || Number(b.confidence) - Number(a.confidence))

  const exclusions = new Set<string>()
  for (const row of exclusionResult.data ?? []) exclusions.add(`${row.ingredient_key}::${row.stock_item_id}`)
  return { memory, exclusions }
}

async function saveStockMemory(ingredientKey: string, stockItem: StockItem, source: 'ai' | 'human' | 'text' | 'exact', confidence: number, reason: string, validated: boolean) {
  const { error } = await mealioServerDb.from('matcher_memory').upsert({
    ingredient_key: ingredientKey,
    stock_item_id: String(stockItem.id),
    source,
    confidence,
    validated,
    reason,
    updated_at: new Date().toISOString(),
  }, { onConflict: 'ingredient_key,stock_item_id' })
  if (error) console.error('matcher_memory upsert:', error.message)
}

export async function validateMatcherDecision(ingredientName: string, stockItem: StockItem, reason = 'Validation utilisateur') {
  const key = cleanText(ingredientName)
  if (!key || !stockItem.id) return
  await saveStockMemory(key, stockItem, 'human', 1, reason, true)
  await mealioServerDb.from('matcher_exclusions').delete().eq('ingredient_key', key).eq('stock_item_id', String(stockItem.id))
}

export async function rejectMatcherDecision(ingredientName: string, stockItem: StockItem, reason = 'Refus utilisateur') {
  const key = cleanText(ingredientName)
  if (!key || !stockItem.id) return
  const { error } = await mealioServerDb.from('matcher_exclusions').upsert({ ingredient_key: key, stock_item_id: String(stockItem.id), reason }, { onConflict: 'ingredient_key,stock_item_id' })
  if (error) console.error('matcher_exclusions upsert:', error.message)
}

export async function forgetMatcherDecision(ingredientName: string, stockItem: StockItem) {
  const key = cleanText(ingredientName)
  if (!key || !stockItem.id) return
  await Promise.all([
    mealioServerDb.from('matcher_memory').delete().eq('ingredient_key', key).eq('stock_item_id', String(stockItem.id)),
    mealioServerDb.from('matcher_exclusions').delete().eq('ingredient_key', key).eq('stock_item_id', String(stockItem.id)),
  ])
}

async function matchOneRequirement(
  item: AggregatedRequirement,
  preparedStock: PreparedStock[],
  memory: Map<string, MemoryRow[]>,
  exclusions: Set<string>,
  stopWords: Set<string>,
  trace?: MatcherTrace
): Promise<{ matchedItems: StockItem[]; needsReview: boolean }> {

  const key = cleanText(item.produit, stopWords)

  if (!key) {
    return {
      matchedItems: [],
      needsReview: item.needs_review,
    }
  }

  // ============================================================
  // 1. MÉMOIRE PERSISTANTE
  // ============================================================

  const remembered = memory.get(key) ?? []

  if (remembered.length && trace) {
    trace.stock.memoryHit = true
    trace.stock.source = 'memory'

    trace.events.push(
      `Mémoire stock trouvée : ${remembered.length} rapprochement(s)`
    )
  }

  for (const row of remembered) {

    const found = preparedStock.find(
      p => p.item.id === row.stock_item_id
    )

    if (!found) continue

    if (
      exclusions.has(
        `${key}::${row.stock_item_id}`
      )
    ) {
      continue
    }

    if (trace) {
      trace.stock.source = 'memory'

      trace.events.push(
        `Mémoire stock utilisée : ${found.item.produit} (${row.source}, confiance ${Number(row.confidence).toFixed(2)})`
      )
    }

    const exactSameProduct = preparedStock.filter(
      p =>
        p.normalized === found.normalized &&
        !exclusions.has(
          `${key}::${p.item.id}`
        )
    )

    return {
      matchedItems: exactSameProduct.map(
        p => p.item
      ),

      needsReview:
        !row.validated &&
        row.confidence < 0.9,
    }
  }


  // ============================================================
  // 2. CORRESPONDANCE EXACTE
  // ============================================================

  const exact = preparedStock.filter(
    p =>
      p.normalized === key &&
      !exclusions.has(
        `${key}::${p.item.id}`
      )
  )

  if (exact.length) {

    if (trace) {
      trace.stock.source = 'exact'

      trace.events.push(
        `Correspondance stock exacte : ${exact[0].item.produit}`
      )
    }

    for (const prepared of exact) {
      await saveStockMemory(
        key,
        prepared.item,
        'exact',
        1,
        'Correspondance exacte après normalisation',
        true
      )
    }

    return {
      matchedItems: exact.map(
        p => p.item
      ),
      needsReview: item.needs_review,
    }
  }


  // ============================================================
  // 3. SCORE LEXICAL
  // ============================================================

  const candidates = preparedStock
    .map(p => ({
      ...p,
      score: textScore(
        item.produit,
        p.item.produit,
        stopWords
      ),
    }))
    .filter(
      p =>
        p.score >= CONFIG.MIN_CANDIDATE_SCORE &&
        !exclusions.has(
          `${key}::${p.item.id}`
        )
    )
    .sort(
      (a, b) =>
        b.score - a.score
    )
    .slice(
      0,
      CONFIG.CANDIDATE_LIMIT
    )

  if (!candidates.length) {

    if (trace) {
      trace.stock.source = 'none'

      trace.events.push(
        'Aucun candidat stock suffisamment proche'
      )
    }

    return {
      matchedItems: [],
      needsReview: item.needs_review,
    }
  }


  // ============================================================
  // 4. MATCH LEXICAL SÛR
  // ============================================================

  if (
    bestIsSafe(
      candidates,
      CONFIG.STOCK_AUTO_SCORE,
      CONFIG.STOCK_AUTO_MARGIN
    )
  ) {

    const selected = candidates[0]

    if (trace) {
      trace.stock.source = 'lexical'

      trace.events.push(
        `Match stock lexical automatique : ${selected.item.produit} (${selected.score.toFixed(2)})`
      )
    }

    await saveStockMemory(
      key,
      selected.item,
      'text',
      selected.score,
      `Match automatique : score ${selected.score.toFixed(2)}`,
      true
    )

    return {
      matchedItems:
        preparedStock
          .filter(
            p =>
              p.normalized ===
                selected.normalized &&
              !exclusions.has(
                `${key}::${p.item.id}`
              )
          )
          .map(
            p => p.item
          ),

      needsReview:
        item.needs_review,
    }
  }


  // ============================================================
  // 5. CLAUDE — UNIQUEMENT SI AMBIGU
  // ============================================================

  if (trace) {
    trace.stock.aiCalled = true
    trace.stock.source = 'ai'
    trace.claudeCalls += 1

    trace.events.push(
      'Claude appelé pour le rapprochement stock'
    )
  }

  const ai =
    await matchStockWithClaude(
      item.produit,
      candidates.map(
        c => ({
          id: c.item.id,
          label: c.item.produit,
          lexicalScore: c.score,
          metadata: {
            source: c.item.source,
          },
        })
      )
    )

  if (trace) {
    trace.stock.aiConfidence =
      ai.confidence ?? null

    trace.events.push(
      `Claude : ${ai.matched ? 'match trouvé' : 'aucun match'} — confiance ${Number(ai.confidence ?? 0).toFixed(2)}`
    )
  }

  if (!ai.matched) {

    return {
      matchedItems: [],
      needsReview: true,
    }
  }

  const selected =
    candidates.find(
      c => c.item.id === ai.matched
    )

  if (!selected) {

    return {
      matchedItems: [],
      needsReview: true,
    }
  }


  // ============================================================
  // 6. APPRENTISSAGE
  // ============================================================

  if (
    ai.confidence >=
    CONFIG.AI_LEARNING_THRESHOLD
  ) {

    await saveStockMemory(
      key,
      selected.item,
      'ai',
      ai.confidence,
      ai.reason,
      false
    )
  }


  return {
    matchedItems:
      preparedStock
        .filter(
          p =>
            p.normalized ===
              selected.normalized &&
            !exclusions.has(
              `${key}::${p.item.id}`
            )
        )
        .map(
          p => p.item
        ),

    needsReview:
      item.needs_review ||
      ai.confidence < 0.85,
  }
}

export async function compareToStock(
  aggregated: AggregatedRequirement[],
  globalStock: StockItem[],
  trace?: MatcherTrace
): Promise<ComparedRequirement[]> {

  const stopWords =
    await loadMatcherStopWords()

  const preparedStock =
    globalStock.map(item => ({
      item,
      normalized: cleanText(
        item.produit,
        stopWords
      ),
      tokens: tokens(
        item.produit,
        stopWords
      ),
    }))

  const keys =
    aggregated.map(
      item =>
        cleanText(
          item.produit,
          stopWords
        )
    )

  const {
    memory,
    exclusions,
  } =
    await loadStockMemory(keys)

  const results:
    ComparedRequirement[] = []

  for (const item of aggregated) {

    const match =
      await matchOneRequirement(
        item,
        preparedStock,
        memory,
        exclusions,
        stopWords,
        trace
      )

    const matchingStockItems =
      match.matchedItems.filter(
        stock =>
          cleanText(
            stock.unite,
            stopWords
          ) ===
          cleanText(
            item.unite,
            stopWords
          )
      )

    const hasUnitMismatch =
      match.matchedItems.some(
        stock =>
          cleanText(
            stock.unite,
            stopWords
          ) !==
          cleanText(
            item.unite,
            stopWords
          )
      )

    const totalStockQty =
      matchingStockItems.reduce(
        (sum, stock) =>
          sum +
          Number(
            stock.qte || 0
          ),
        0
      )

    const qte_a_acheter =
      Math.max(
        0,
        item.qte -
          totalStockQty
      )

    let ai_status:
      'green' |
      'orange' |
      'red' = 'red'

    if (
      totalStockQty >=
      item.qte
    ) {
      ai_status = 'green'

    } else if (
      totalStockQty > 0
    ) {
      ai_status = 'orange'

    } else if (
      hasUnitMismatch ||
      match.needsReview
    ) {
      ai_status = 'orange'
    }

    results.push({
      ...item,
      qte_a_acheter,
      ai_status,
      needs_review:
        item.needs_review ||
        match.needsReview,
    })
  }

  return results
}

export async function loadMatcherStopWords(): Promise<Set<string>> {
  const { data, error } = await mealioServerDb.from('ignored_words').select('mot')
  const set = new Set(BASE_STOP_WORDS)
  if (error) console.error('ignored_words:', error.message)
  for (const row of data ?? []) {
    const value = cleanText(String(row.mot ?? ''), BASE_STOP_WORDS)
    if (value) set.add(value)
  }
  return set
}
