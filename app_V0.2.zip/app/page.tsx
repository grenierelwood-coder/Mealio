'use client'

import Link from 'next/link'

export default function Home() {
  return (
    <main className="min-h-screen bg-stone-50 text-slate-900">
      <div className="mx-auto max-w-7xl px-5 py-8">
        <section className="rounded-3xl bg-emerald-800 p-7 text-white shadow-sm">
          <p className="text-sm font-semibold uppercase tracking-[0.2em] text-emerald-200">Mealio</p>
          <h1 className="mt-2 text-3xl font-black sm:text-4xl">Votre cuisine, pilotée par le stock réel.</h1>
          <p className="mt-3 max-w-3xl text-emerald-50">
            Planning, courses, achats, stocks, rangement et réapprovisionnement réunis dans un même foyer.
          </p>
          <div className="mt-6 flex flex-wrap gap-3">
            <Link href="/anti-gaspi" className="rounded-xl bg-white px-5 py-3 font-bold text-emerald-800 hover:bg-emerald-50">
              🍽️ Qu’est-ce qu’on mange ce soir ?
            </Link>
            <Link href="/courses" className="rounded-xl border border-emerald-400 px-5 py-3 font-bold text-white hover:bg-emerald-700">
              🛒 Ouvrir les courses
            </Link>
          </div>
        </section>

        <section className="mt-7 grid gap-5 md:grid-cols-2 lg:grid-cols-4">
          <Link href="/planning" className="rounded-2xl border bg-white p-5 hover:-translate-y-0.5 hover:shadow-sm">
            <div className="text-2xl">📅</div>
            <h2 className="mt-3 font-bold">Planning</h2>
            <p className="mt-1 text-sm text-slate-600">Planifier les repas et ajuster les portions.</p>
          </Link>
          <Link href="/courses" className="rounded-2xl border bg-white p-5 hover:-translate-y-0.5 hover:shadow-sm">
            <div className="text-2xl">🛒</div>
            <h2 className="mt-3 font-bold">Courses</h2>
            <p className="mt-1 text-sm text-slate-600">Générer, compléter et acheter la liste du foyer.</p>
          </Link>
          <Link href="/stock" className="rounded-2xl border bg-white p-5 hover:-translate-y-0.5 hover:shadow-sm">
            <div className="text-2xl">❄️</div>
            <h2 className="mt-3 font-bold">Stock</h2>
            <p className="mt-1 text-sm text-slate-600">Voir Frosti + Cellio et corriger le stock réel.</p>
          </Link>
          <Link href="/point-frigo" className="rounded-2xl border bg-white p-5 hover:-translate-y-0.5 hover:shadow-sm">
            <div className="text-2xl">🧊</div>
            <h2 className="mt-3 font-bold">Point Frigo</h2>
            <p className="mt-1 text-sm text-slate-600">Faire rapidement le recalage du stock du foyer.</p>
          </Link>
        </section>
      </div>
    </main>
  )
}
