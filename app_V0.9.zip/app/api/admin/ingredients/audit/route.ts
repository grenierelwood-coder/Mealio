import { NextResponse } from 'next/server'
import { getAuthSession } from '../../../../utils/auth-server'
import { mealioServerDb } from '../../../../lib/supabase-server'

type Issue = { code:string; severity:'error'|'warning'|'info'; category?:'referentiel'|'synonymes'|'equivalences'|'donnees'|'unites'; title:string; message:string; ingredientId?:string; ingredientName?:string; unit?:string|null; relatedTable?:string; relatedCount?:number; synonym?:string|null }
const norm=(v:unknown)=>String(v??'').normalize('NFD').replace(/[\u0300-\u036f]/g,'').trim().toLowerCase()

export async function GET(){
  if(!await getAuthSession()) return NextResponse.json({error:'Non authentifié.'},{status:401})
  const [ingredients,synonyms,units,densities,conversions,shopping,purchases,recurring,thresholds,favorites]=await Promise.all([
    mealioServerDb.from('official_ingredients').select('id,nom,categorie,rayon,default_storage,default_is_fridge,unite_reference').order('nom'),
    mealioServerDb.from('ingredient_synonyms').select('mot_recette,ingredient_id'),
    mealioServerDb.from('unit_mappings').select('unite,abreviation,type_unite,equivalence_reference,multiplicateur'),
    mealioServerDb.from('ingredient_densities').select('ingredient_id,unite,poids_g_approx'),
    mealioServerDb.from('ingredient_unit_conversions').select('*'),
    mealioServerDb.from('shopping_items').select('ingredient_id,unite').limit(10000),
    mealioServerDb.from('shopping_purchase_events').select('ingredient_id,unite').limit(10000),
    mealioServerDb.from('recurring_purchase_rules').select('ingredient_id,unite').limit(10000),
    mealioServerDb.from('stock_replenishment_thresholds').select('ingredient_id,unite').limit(10000),
    mealioServerDb.from('favorite_preferences').select('ingredient_id,unite').limit(10000),
  ])
  const results=[ingredients,synonyms,units,densities,conversions,shopping,purchases,recurring,thresholds,favorites]; const failed=results.find(r=>r.error)
  if(failed?.error) return NextResponse.json({error:failed.error.message},{status:500})
  const ing=ingredients.data??[], syn=synonyms.data??[], unitRows=units.data??[], densityRows=densities.data??[], conversionRows=conversions.data??[]
  const usageTables=[
    {name:'shopping_items',rows:shopping.data??[]},{name:'shopping_purchase_events',rows:purchases.data??[]},{name:'recurring_purchase_rules',rows:recurring.data??[]},{name:'stock_replenishment_thresholds',rows:thresholds.data??[]},{name:'favorite_preferences',rows:favorites.data??[]},
  ]
  const ingredientById=new Map(ing.map(i=>[i.id,i])); const unitByNorm=new Map(unitRows.map(u=>[norm(u.unite),u])); const issues:Issue[]=[]
  const push=(x:Issue)=>{ if(!x.category){ const c=x.code; x.category=c.includes('SYNONYM')?'synonymes':(c.includes('DENSITY')||c.includes('CONVERSION')||c.includes('EQUIVALENCE')?'equivalences':(c.includes('UNIT')||c.includes('REFERENCE_UNIT')?'unites':(c.includes('USAGE')||c.includes('HISTORICAL')||c.includes('ORPHAN_USAGE')?'donnees':'referentiel'))) } issues.push(x) }

  for(const i of ing){
    if(!String(i.nom??'').trim()) push({code:'INGREDIENT_NAME_MISSING',severity:'error',title:'Nom manquant',message:'L’ingrédient officiel n’a pas de nom.',ingredientId:i.id})
    if(!String(i.categorie??'').trim()) push({code:'CATEGORY_MISSING',severity:'error',title:'Catégorie manquante',message:'La catégorie est vide.',ingredientId:i.id,ingredientName:i.nom})
    if(!String(i.rayon??'').trim()) push({code:'RAYON_MISSING',severity:'error',title:'Rayon manquant',message:'Le rayon est vide et ne peut pas servir au parcours magasin.',ingredientId:i.id,ingredientName:i.nom})
    if(i.default_storage!=='frosti'&&i.default_storage!=='cellio') push({code:'STORAGE_MISSING',severity:'error',title:'Destination de stock manquante',message:'La destination doit être Frosti ou Cellio.',ingredientId:i.id,ingredientName:i.nom})
    if(i.default_is_fridge===null||i.default_is_fridge===undefined) push({code:'FRIDGE_MISSING',severity:'error',title:'Règle frigo manquante',message:'Le champ frigo n’est pas défini.',ingredientId:i.id,ingredientName:i.nom})
    if(!String(i.unite_reference??'').trim()) push({code:'REFERENCE_UNIT_MISSING',severity:'error',title:'Unité de référence manquante',message:'Aucune unité de référence n’est définie.',ingredientId:i.id,ingredientName:i.nom})
    else if(!unitByNorm.has(norm(i.unite_reference))) push({code:'REFERENCE_UNIT_UNKNOWN',severity:'error',title:'Unité de référence inconnue',message:`L’unité « ${i.unite_reference} » n’existe pas dans unit_mappings.`,ingredientId:i.id,ingredientName:i.nom,unit:i.unite_reference})
  }
  const names=new Map<string,typeof ing>(); for(const i of ing){const k=norm(i.nom);if(!k)continue;const a=names.get(k)??[];a.push(i);names.set(k,a)}
  for(const a of names.values()) if(a.length>1) push({code:'DUPLICATE_INGREDIENT_NAME',severity:'error',title:'Noms d’ingrédients en doublon',message:`Même nom après normalisation : ${a.map(x=>x.nom).join(' / ')}.`,ingredientId:a[0].id,ingredientName:a[0].nom})

  const synonymNames=new Map<string,typeof syn>(); for(const s of syn){if(!ingredientById.has(s.ingredient_id)) push({code:'ORPHAN_SYNONYM',severity:'error',title:'Synonyme orphelin',message:`« ${s.mot_recette} » pointe vers un ingrédient inexistant.`,relatedTable:'ingredient_synonyms',synonym:s.mot_recette});const k=norm(s.mot_recette);if(k){const a=synonymNames.get(k)??[];a.push(s);synonymNames.set(k,a)}}
  for(const [key,a] of synonymNames){if(new Set(a.map(s=>s.ingredient_id)).size>1) push({code:'AMBIGUOUS_SYNONYM',severity:'error',title:'Synonyme ambigu',message:`« ${a[0].mot_recette} » pointe vers plusieurs ingrédients.`,relatedTable:'ingredient_synonyms',synonym:a[0].mot_recette});if(a.some(s=>norm(ingredientById.get(s.ingredient_id)?.nom)===key))push({code:'REDUNDANT_SYNONYM',severity:'error',title:'Synonyme redondant',message:`« ${a[0].mot_recette} » est identique au nom de sa cible : « ${ingredientById.get(a[0].ingredient_id)?.nom??'—'} ». Le synonyme n’apporte aucune information supplémentaire.`,relatedTable:'ingredient_synonyms',ingredientId:a[0].ingredient_id,ingredientName:ingredientById.get(a[0].ingredient_id)?.nom,synonym:a[0].mot_recette})}

  for(const d of densityRows){if(!ingredientById.has(d.ingredient_id))push({code:'ORPHAN_DENSITY',severity:'error',title:'Équivalence orpheline',message:'L’équivalence pointe vers un ingrédient inexistant.',relatedTable:'ingredient_densities'});if(!unitByNorm.has(norm(d.unite)))push({code:'DENSITY_UNIT_UNKNOWN',severity:'error',title:'Unité d’équivalence inconnue',message:`« ${d.unite} » n’existe pas dans unit_mappings.`,relatedTable:'ingredient_densities',unit:d.unite});if(!(Number(d.poids_g_approx)>0))push({code:'DENSITY_INVALID',severity:'error',title:'Équivalence invalide',message:`Le poids associé à 1 ${d.unite} doit être positif.`,relatedTable:'ingredient_densities',unit:d.unite})}
  for(const c of conversionRows){if(c.ingredient_id&&!ingredientById.has(c.ingredient_id))push({code:'ORPHAN_CONVERSION',severity:'error',title:'Conversion orpheline',message:'La conversion pointe vers un ingrédient inexistant.',relatedTable:'ingredient_unit_conversions'});if(!unitByNorm.has(norm(c.from_unit)))push({code:'CONVERSION_SOURCE_UNIT_UNKNOWN',severity:'error',title:'Unité source inconnue',message:`« ${c.from_unit} » n’existe pas dans unit_mappings.`,relatedTable:'ingredient_unit_conversions',unit:c.from_unit});if(!unitByNorm.has(norm(c.to_unit)))push({code:'CONVERSION_TARGET_UNIT_UNKNOWN',severity:'error',title:'Unité cible inconnue',message:`« ${c.to_unit} » n’existe pas dans unit_mappings.`,relatedTable:'ingredient_unit_conversions',unit:c.to_unit});if(!(Number(c.multiplier)>0))push({code:'CONVERSION_INVALID_MULTIPLIER',severity:'error',title:'Multiplicateur invalide',message:'Le multiplicateur doit être positif.',relatedTable:'ingredient_unit_conversions'})}

  for(const table of usageTables){const grouped=new Map<string,{unit:string,count:number}>();for(const row of table.rows){if(!row.ingredient_id)continue;const ingredient=ingredientById.get(row.ingredient_id);if(!ingredient){push({code:'ORPHAN_USAGE',severity:'error',title:'Donnée opérationnelle orpheline',message:`Une ligne de ${table.name} référence un ingrédient inexistant.`,relatedTable:table.name});continue}if(row.unite&&!unitByNorm.has(norm(row.unite)))push({code:'USAGE_UNIT_UNKNOWN',severity:'error',title:'Unité historique inconnue',message:`« ${row.unite} » n’existe pas dans unit_mappings.`,ingredientId:ingredient.id,ingredientName:ingredient.nom,unit:row.unite,relatedTable:table.name});if(row.unite&&ingredient.unite_reference&&norm(row.unite)!==norm(ingredient.unite_reference)){const k=`${ingredient.id}|${norm(row.unite)}|${table.name}`;const cur=grouped.get(k);grouped.set(k,{unit:row.unite,count:(cur?.count??0)+1})}}for(const [k,v] of grouped){const [ingredientId]=k.split('|');const ingredient=ingredientById.get(ingredientId);push({code:'HISTORICAL_UNIT_MISMATCH',severity:'warning',title:'Unité historique différente',message:`${v.count} ligne(s) utilisent « ${v.unit} » alors que la référence actuelle est « ${ingredient?.unite_reference??'non définie'} ». Ce n’est pas automatiquement une erreur : à examiner avant migration.`,ingredientId,ingredientName:ingredient?.nom,unit:v.unit,relatedTable:table.name,relatedCount:v.count})}}
  for(const u of unitRows){const family=String(u.type_unite??'').trim().toLowerCase();if(!family)push({code:'UNIT_FAMILY_MISSING',severity:'error',title:'Famille d’unité manquante',message:`« ${u.unite} » n’a pas de famille.`,relatedTable:'unit_mappings',unit:u.unite});else if(!['poids','volume','divers'].includes(family))push({code:'UNIT_FAMILY_UNKNOWN',severity:'error',title:'Famille d’unité inconnue',message:`« ${u.unite} » a une famille « ${u.type_unite} » non reconnue.`,relatedTable:'unit_mappings',unit:u.unite});if(u.multiplicateur!==null&&u.multiplicateur!==undefined&&!(Number(u.multiplicateur)>0))push({code:'UNIT_MULTIPLIER_INVALID',severity:'error',title:'Multiplicateur d’unité invalide',message:`Le multiplicateur de « ${u.unite} » doit être positif.`,relatedTable:'unit_mappings',unit:u.unite})}

  const summary={ingredients:ing.length,units:unitRows.length,synonyms:syn.length,densities:densityRows.length,conversions:conversionRows.length,usageRows:usageTables.reduce((n,t)=>n+t.rows.length,0),errors:issues.filter(i=>i.severity==='error').length,warnings:issues.filter(i=>i.severity==='warning').length,infos:issues.filter(i=>i.severity==='info').length}
  const grouped=Array.from(new Map(issues.map(i=>[i.code,i])).values()).map(i=>({...i,count:issues.filter(x=>x.code===i.code).length}))
  return NextResponse.json({generatedAt:new Date().toISOString(),summary,issues,grouped})
}
