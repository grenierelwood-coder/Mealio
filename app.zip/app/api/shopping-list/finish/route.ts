import { NextResponse } from 'next/server'
import { cookies } from 'next/headers'
import { mealioServerDb } from '../../../lib/supabase-server'

async function getUsername(): Promise<string | null> {
  const cookieStore = await cookies()

  return (
    cookieStore
      .get('congelo_username')
      ?.value
      ?.trim() || null
  )
}

/**
 * POST
 *
 * Termine la liste de courses active du foyer.
 *
 * Important :
 * - le username vient exclusivement du cookie ;
 * - le client ne fournit jamais le list_id ;
 * - seule la liste "en_cours" du foyer peut être terminée.
 */
export async function POST() {
  const username = await getUsername()

  if (!username) {
    return NextResponse.json(
      {
        error: 'Non authentifié.',
      },
      { status: 401 }
    )
  }

  try {
    /*
     * Recherche de la liste active du foyer.
     */
    const {
      data: activeList,
      error: listError,
    } = await mealioServerDb
      .from('shopping_lists')
      .select(`
        id,
        created_at,
        user_id,
        name,
        status,
        period_start,
        period_end
      `)
      .eq('user_id', username)
      .eq('status', 'en_cours')
      .order('created_at', {
        ascending: false,
      })
      .limit(1)
      .maybeSingle()

    if (listError) {
      console.error(
        '❌ Erreur recherche liste active :',
        listError
      )

      return NextResponse.json(
        {
          error:
            `Impossible de récupérer la liste active : ${listError.message}`,
        },
        { status: 500 }
      )
    }

    if (!activeList) {
      return NextResponse.json(
        {
          error:
            'Aucune liste de courses active à terminer.',
        },
        { status: 404 }
      )
    }

    /*
     * Termine la liste.
     *
     * La condition user_id + id + status protège
     * contre toute modification hors du foyer.
     */
    const {
      data: finishedList,
      error: updateError,
    } = await mealioServerDb
      .from('shopping_lists')
      .update({
        status: 'terminee',
      })
      .eq('id', activeList.id)
      .eq('user_id', username)
      .eq('status', 'en_cours')
      .select(`
        id,
        created_at,
        user_id,
        name,
        status,
        period_start,
        period_end
      `)
      .single()

    if (updateError || !finishedList) {
      console.error(
        '❌ Erreur terminaison liste :',
        updateError
      )

      return NextResponse.json(
        {
          error:
            updateError?.message ||
            'Impossible de terminer la liste de courses.',
        },
        { status: 500 }
      )
    }

    console.log(
      `✅ Liste de courses terminée pour ${username} : ${finishedList.id}`
    )

    return NextResponse.json({
      list: finishedList,
      message:
        'Courses terminées avec succès.',
    })
  } catch (error) {
    console.error(
      '❌ Erreur inattendue POST /api/shopping-list/finish :',
      error
    )

    return NextResponse.json(
      {
        error:
          error instanceof Error
            ? error.message
            : 'Erreur interne.',
      },
      { status: 500 }
    )
  }
}